# TIANGONG V2 Anchor D — Cloudflare Workers 修正版部署包

这是 **TIANGONG — A Browser-Based Orbital Experience** 的 Cloudflare Workers + Static Assets 部署包。

> 非官方个人概念作品，与任何官方航天机构无隶属、授权或背书关系。

## 本修正版做了什么

- 将 `wrangler.jsonc` 的 Worker 名称统一为 **`worker`**，与当前 Cloudflare Dashboard 中的 Worker 对齐。
- 同步修正 `dist/server/wrangler.json` 中的 Worker 名称。
- ZIP 已改为**扁平结构**：解压后 `package.json`、`wrangler.jsonc`、`dist/` 直接出现在当前目录，不再多套一层文件夹。
- 不改动 3D 模型、贴图、网页代码和已构建产物。

## GitHub + Cloudflare Workers Builds（推荐，手机也能做）

将整个 `TIANGONG_V2_WORKER_FIXED.zip` 作为**一个文件**上传到 GitHub 仓库 `main` 分支。

Cloudflare → Worker `worker` → **Settings → Builds**：

### Build command

```bash
rm -rf dist && unzip -q -o TIANGONG_V2_WORKER_FIXED.zip && bun install
```

### Deploy command

```bash
npx wrangler deploy --config wrangler.jsonc
```

### Root directory

```text
/
```

### Production branch

```text
main
```

上传这个 ZIP 到 `main` 本身会产生一次 commit，Cloudflare Git integration 会自动触发新构建。

成功日志应依次出现：Build command → `bun install` → Wrangler deploy → 静态资源上传 → Worker 部署完成。

## 核心部署文件

- `wrangler.jsonc` — Worker `worker` 的正式配置
- `dist/server/index.js` — Worker 入口
- `dist/client/` — 网站、3D 模型、贴图和前端静态资源
- `package.json` — Wrangler 4.92.0 依赖与部署脚本

## 本地/电脑部署（备用）

```bash
npm install
npx wrangler login
npm run deploy
```

## 常见报错

### `The entry-point file at "dist/server/index.js" was not found`
说明 ZIP 没有在 deploy 之前解压。确认 Build command 正确并且日志里出现 Build command 执行记录。

### 页面仍然是 `Hello World`
说明当前线上仍是旧的默认 Worker 版本；检查最新 Git 构建是否真正成功并部署到 `worker`。

### GitHub User / Organization details error
这是 Cloudflare GitHub integration 授权/元数据问题。若构建连 `Cloning repository...` 都无法完成，在 Settings → Builds 重新管理/授权 GitHub integration。
